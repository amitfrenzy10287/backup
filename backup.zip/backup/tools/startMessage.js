import colors from 'colors';

/*eslint-disable no-console*/
console.log('Start app in dev mode ...'.green);
