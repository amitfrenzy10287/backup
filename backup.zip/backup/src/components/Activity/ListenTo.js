import React, {Component} from 'react';

export default class ListenTo extends Component {
  render() {
    return(
      <h1>Listen to</h1>
    );
  }
}
