import React, {Component} from 'react';

export default class EngagedBy extends Component {
  render() {
    return(
      <h1>Engaged by</h1>
    );
  }
}
