import React, {Component} from 'react';

 class LatestNews extends Component {
  render() {
    return(
      <div>latest News</div>
    );
  }
}

export default LatestNews;
