import React, {Component} from 'react';

export default class TopTweet extends Component {
  render() {
    return(
      <h1>latest tweets</h1>
    );
  }
}
