# SocialPolitics
npm install
npm start
